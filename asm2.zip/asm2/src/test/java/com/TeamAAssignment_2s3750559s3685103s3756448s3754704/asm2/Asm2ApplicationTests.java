package com.TeamAAssignment_2s3750559s3685103s3756448s3754704.asm2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Asm2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
