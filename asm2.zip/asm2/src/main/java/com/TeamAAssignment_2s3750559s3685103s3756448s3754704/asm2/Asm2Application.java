package com.TeamAAssignment_2s3750559s3685103s3756448s3754704.asm2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Asm2Application {

	public static void main(String[] args) {
		SpringApplication.run(Asm2Application.class, args);
	}

}
